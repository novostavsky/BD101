package com.epam.hubd.spark.scala.sql.homework

import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.functions._

object MotelsHomeRecommendation {

  val ERRONEOUS_DIR: String = "erroneous"
  val AGGREGATED_DIR: String = "aggregated"

  def main(args: Array[String]): Unit = {
    require(args.length == 4, "Provide parameters in this order: bidsPath, motelsPath, exchangeRatesPath, outputBasePath")

    val bidsPath = args(0)
    val motelsPath = args(1)
    val exchangeRatesPath = args(2)
    val outputBasePath = args(3)

    //run C:\hadoop\bin>winutils.exe chmod 777 \tmp\hive
    //set-up config from the app - setMaster("local[1]"))
    val sc = new SparkContext(new SparkConf().setAppName("motels-home-recommendation").setMaster("local[1]"))

//    val sqlContext = new HiveContext(sc) //this thing never worked with hiveContext
    val sqlContext = new SQLContext(sc)    //I switched to SQLContext, and with a piece of hammer made it run

    processData(sqlContext, bidsPath, motelsPath, exchangeRatesPath, outputBasePath)

    sc.stop()
  }

  /**
    * Main function that read and process the data
    * Consists of a few steps / Tasks with detailed description
    */
  def processData(sqlContext: SQLContext, bidsPath: String, motelsPath: String, exchangeRatesPath: String, outputBasePath: String) = {

    /**
      * Task 1:
      * Read the bid data from the provided file.
      */
    val rawBids: DataFrame = getRawBids(sqlContext, bidsPath)

    /**
      * Task 1:
      * Collect the errors and save the result.
      */
    val erroneousRecords: DataFrame = getErroneousRecords(rawBids)
    erroneousRecords.write
      .format(Constants.CSV_FORMAT)
      .save(s"$outputBasePath/$ERRONEOUS_DIR")

    /**
      * Task 2:
      * Read the exchange rate information.
      * Hint: You will need a mapping between a date/time and rate
      */
    val exchangeRates: DataFrame = getExchangeRates(sqlContext, exchangeRatesPath)

    /**
      * Task 3:
      * UserDefinedFunction to convert between date formats.
      * Hint: Check the formats defined in Constants class
      */
    val convertDate: UserDefinedFunction = getConvertDate

    /**
      * Task 3:
      * Transform the rawBids
      * - Convert USD to EUR. The result should be rounded to 3 decimal precision.
      * - Convert dates to proper format - use formats in Constants util class
      * - Get rid of records where there is no price for a Losa or the price is not a proper decimal number
      */
    val bids: DataFrame = getBids(rawBids, exchangeRates)

    /**
      * Task 4:
      * Load motels data.
      * Hint: You will need the motels name for enrichment and you will use the id for join
      */
    val motels: DataFrame = getMotels(sqlContext, motelsPath)

    /**
      * Task5:
      * Join the bids with motel names.
      */
    val enriched: DataFrame = getEnriched(bids, motels)
    enriched.write
      .format(Constants.CSV_FORMAT)
      .save(s"$outputBasePath/$AGGREGATED_DIR")
  }

  /**
    * Reads raw bids data from file for later use in transformations
    */
  def getRawBids(sqlContext: SQLContext, bidsPath: String): DataFrame = sqlContext
    .read
    .format("com.databricks.spark.csv")
    .schema(Constants.BIDS_HEADER)
    .option("header", "false")
    .load(bidsPath)

  /**
    * Filter error data (w/o bids actualy)
    * and count number of such errors per (motel, date-hour) tuple
    * for later analysis went and when went wrong
    */
  def getErroneousRecords(rawBids: DataFrame): DataFrame = rawBids
    .filter("HU like 'ERROR_%'")
    .groupBy("MotelID", "BidDate")
    .count()

  /**
    *Read exchange rates file to recalculate prices in EUR - output EUR rates per date
    * NOTE: the file contains EUR only, but maybe with other input data you may need additional filter
    */
  def getExchangeRates(sqlContext: SQLContext, exchangeRatesPath: String): DataFrame = sqlContext
    .read
    .format("com.databricks.spark.csv")
    .schema(Constants.EXCHANGE_RATES_HEADER)
    .option("header", "false")
    .load(exchangeRatesPath)
    .select("ValidFrom", "CurrencyCode", "ExchangeRate")
//    .filter("CurrencyCode === 'EUR'")

  /**
    * Date conversion from input forma used in source files to expected output format
    * NOTE: used UserDefinedFunction wrapping for ease
    * NOTE: formats itself are defined in Constants object
    */
  def dateConvert: (String => String) = { date =>
    Constants.OUTPUT_DATE_FORMAT.print(
      Constants.INPUT_DATE_FORMAT.parseDateTime(date) )
  }
  def getConvertDate: UserDefinedFunction = udf(dateConvert)

  /**
    * Get bids from one state/losa only in expected format (state data from col to row):
    *   input data: "MotelID", "BidDate", "HU", "UK",  "NL", "US", "MX"...
    *                0000001 , HH-dd-MM-yyyy, 1, 2, 3, 4, 5 ...
    *   output data (for state = "US"): "MotelID", "BidDate", "Losa", "Amount"
    *                                    0000001 , HH-dd-MM-yyyy, US, 4
    */
  def getStateBids(rawBids: DataFrame, state: String): DataFrame = rawBids
    .filter("HU not like 'ERROR_%'")
    .withColumn("Losa", lit(state))
    .select("MotelID", "BidDate", "Losa", state)
    .withColumnRenamed(state, "Amount")

  /**
    * Simple round to decimal presision 3
    * for use in final money rounding before output
    */
  val roundUdf = udf( (x: Double) =>
                          BigDecimal(x).setScale(3, BigDecimal.RoundingMode.HALF_UP).toDouble )

  /**
    * Get only bids we're interested in (North America  -US, CA, MX)
    * in expected format (prices in EUR + all money rounded to precision 3 +
    * + date in expected date formats - "yyyy-MM-dd HH:mm")
    */
  def getBids(rawBids: DataFrame, exchangeRates: DataFrame): DataFrame = {
    val usBids = getStateBids(rawBids, "US")
    val caBids = getStateBids(rawBids, "CA")
    val mxBids = getStateBids(rawBids, "MX")

    val northAmreicaBids = usBids.unionAll(caBids).unionAll(mxBids)

    val jointBids = usBids.unionAll(caBids)
      .unionAll(mxBids)
      .join(exchangeRates, northAmreicaBids("BidDate") === exchangeRates("ValidFrom"))

    val col=jointBids.col("Amount")*jointBids.col("ExchangeRate")
    val result = jointBids.withColumn("Price", col.cast("double"))

    return result.withColumn("RoundedPrice", roundUdf(result("Price")))
      .withColumn("NewDate", getConvertDate(result("BidDate")))
      .select("MotelID", "NewDate", "Losa", "RoundedPrice")
  }

  /**
    * Read motels data from a file
    * in order to use motel names assosiated with bids
    */
  def getMotels(sqlContext: SQLContext, motelsPath: String): DataFrame = sqlContext
    .read
    .format("com.databricks.spark.csv")
    .schema(Constants.MOTELS_HEADER)
    .option("header", "false")
    .load(motelsPath)
    .select("MotelID", "MotelName")

  /**
    * Get resulted data output -
    * Max price/bid in EUR for a hotel (used with human-readable hotel name)
    * for certain datetime stamp
    */
  def getEnriched(bids: DataFrame, motels: DataFrame): DataFrame = {
    val bidsRenamed = bids.withColumnRenamed("MotelID", "bidsMotelID")
    val richBids =  bidsRenamed
      .join(motels, bidsRenamed("bidsMotelID") === motels("MotelID"))
      .select("MotelID", "MotelName", "NewDate", "Losa", "RoundedPrice")

    val maxBid = richBids
      .select("MotelID", "NewDate","RoundedPrice")
      .groupBy("MotelID", "NewDate")
      .agg(max("RoundedPrice"))
      .withColumnRenamed("MotelID","nMotelID")
      .withColumnRenamed("NewDate","nNewDate")
      .withColumnRenamed("max(RoundedPrice)","nRoundedPrice")

    return richBids
      .join(maxBid, richBids("MotelID") === maxBid("nMotelID") &&
                      richBids("NewDate") === maxBid("nNewDate") &&
                        richBids("RoundedPrice") === maxBid("nRoundedPrice"))
      .select("MotelID", "MotelName", "NewDate", "Losa", "RoundedPrice")
  }
}
